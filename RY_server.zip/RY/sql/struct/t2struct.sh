rm -f *.h
#table2struct tbl_srv_param &&  table2struct tbl_srv_param > tbl_srv_param.h  && struct tbl_srv_param.h 
#table2struct sys_job &&  table2struct sys_job > sys_job.h  && struct sys_job.h 
table2struct tbl_srv_param &&  table2struct tbl_srv_param > tbl_srv_param.h  && struct tbl_srv_param.h 
