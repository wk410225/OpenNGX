cp $1 /tmp/$1.bak
iconv -f gbk -t utf-8 $1 > a.txt
mv a.txt $1
