#!/bin/bash
cd ~;
#ctags --langmap=c:+.pc -f ~/.tags -R *; cd -
ctags --langmap=c:+.pc -f ~/.tags -R *; cd -
